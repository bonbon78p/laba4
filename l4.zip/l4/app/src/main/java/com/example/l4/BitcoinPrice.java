package com.example.l4;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "bitcoin_price")
public class BitcoinPrice {
    @PrimaryKey(autoGenerate = true)
    public long id;
    public String price;
    public long timestamp; // Time in milliseconds

    public BitcoinPrice(String price, long timestamp) {
        this.price = price;
        this.timestamp = timestamp;
    }
}

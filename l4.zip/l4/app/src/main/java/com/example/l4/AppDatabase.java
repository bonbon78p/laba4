package com.example.l4;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {BitcoinPrice.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {
    public abstract BitcoinPriceDao bitcoinPriceDao();

    private static volatile AppDatabase INSTANCE;

    public static AppDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    AppDatabase.class, "bitcoin_price_database")
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}

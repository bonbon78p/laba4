
package com.example.l4;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {

    private TextView bitcoinPriceTextView;
    private RecyclerView recyclerView;
    private BitcoinPriceAdapter adapter;
    private AppDatabase db;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Gson gson = new GsonBuilder().create();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final long UPDATE_INTERVAL = 20000; //
    private final Runnable updatePriceRunnable = this::fetchAndSavePrice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bitcoinPriceTextView = findViewById(R.id.bitcoin_price_display);
        recyclerView = findViewById(R.id.recyclerView);
        db = AppDatabase.getDatabase(this);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new BitcoinPriceAdapter();
        recyclerView.setAdapter(adapter);

        EdgeToEdge.enable(this);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        handler.postDelayed(updatePriceRunnable, UPDATE_INTERVAL);
    }

    @SuppressLint("SetTextI18n")
    private void fetchAndSavePrice() {
        executor.execute(() -> {
            String price = null;
            boolean success = false;
            int retryCount = 0;
            while (retryCount < 3 && !success) {
                try {
                    String response = fetchBitcoinPrice();
                    if (response != null) {
                        BitcoinPriceData data = gson.fromJson(response, BitcoinPriceData.class);
                        if (data != null && data.bpi != null && data.bpi.USD != null) {
                            price = data.bpi.USD.rate;
                            success = true;
                            long timestamp = System.currentTimeMillis();
                            BitcoinPrice newPrice = new BitcoinPrice(price, timestamp);
                            db.bitcoinPriceDao().insert(newPrice);
                            Log.d("MainActivity", "Price inserted successfully: " + price);

                            // Вызываем updateUI() после успешной вставки
                            runOnUiThread(this::updateUI); // Упрощенная запись

                        } else {
                            Log.e("MainActivity", "Invalid JSON response");
                        }
                    } else {
                        Log.e("MainActivity", "Empty or null response from API");
                    }
                } catch (IOException | JsonSyntaxException e) {
                    Log.e("MainActivity", "Error fetching Bitcoin price: " + e.getMessage(), e);
                    retryCount++;
                    try {
                        TimeUnit.SECONDS.sleep(retryCount); // Exponential backoff
                    } catch (InterruptedException interruptedException) {
                        Thread.currentThread().interrupt();
                    }
                }
            }
            // Обновляем UI вне цикла while (только для отображения текущей цены)
            boolean finalSuccess = success;
            String finalPrice = price;
            runOnUiThread(() -> {
                if (finalSuccess) {
                    bitcoinPriceTextView.setText("Текущий курс BTC: " + finalPrice + "(USD)");
                } else {
                    showError();
                }
            });
            handler.postDelayed(updatePriceRunnable, UPDATE_INTERVAL);
        });
    }

    private void updateUI() {
        executor.execute(() -> {
            List<BitcoinPrice> prices = db.bitcoinPriceDao().getAllPrices();
            runOnUiThread(() -> {
                adapter.submitList(prices);
            });
        });
    }



    private void showError() {
        runOnUiThread(() -> bitcoinPriceTextView.setText("Ошибка загрузки данных"));
    }

    private String fetchBitcoinPrice() throws IOException {
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(1, TimeUnit.SECONDS)
                .readTimeout(1, TimeUnit.SECONDS)
                .build();

        Request request = new Request.Builder()
                .url("https://api.coindesk.com/v1/bpi/currentprice.json")
                .build();

        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                throw new IOException("Unexpected code " + response);
            }
            return response.body().string();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdown();
        handler.removeCallbacks(updatePriceRunnable);
    }

    class BitcoinPriceData {
        Bpi bpi;

        class Bpi {
            Usd USD;

            class Usd {
                String rate;
            }
        }
    }
}

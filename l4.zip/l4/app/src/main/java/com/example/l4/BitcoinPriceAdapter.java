package com.example.l4;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class BitcoinPriceAdapter extends ListAdapter<BitcoinPrice, BitcoinPriceAdapter.ViewHolder> {

    public BitcoinPriceAdapter() {
        super(new DiffUtil.ItemCallback<BitcoinPrice>() {
            @Override
            public boolean areItemsTheSame(@NonNull BitcoinPrice oldItem, @NonNull BitcoinPrice newItem) {
                return oldItem.id == newItem.id;
            }

            @Override
            public boolean areContentsTheSame(@NonNull BitcoinPrice oldItem, @NonNull BitcoinPrice newItem) {
                return oldItem.equals(newItem);
            }
        });
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView priceTextView;
        TextView timestampTextView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            priceTextView = itemView.findViewById(R.id.priceTextView);
            timestampTextView = itemView.findViewById(R.id.timestampTextView);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_bitcoin_price, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        BitcoinPrice bitcoinPrice = getItem(position);
        holder.priceTextView.setText(bitcoinPrice.price);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss dd.MM.yyyy").withZone(ZoneId.systemDefault());
        String formattedTime = formatter.format(Instant.ofEpochMilli(bitcoinPrice.timestamp));
        holder.timestampTextView.setText(formattedTime);
    }
}

package com.example.l4;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import java.util.List;

@Dao
public interface BitcoinPriceDao {
    @Insert
    void insert(BitcoinPrice bitcoinPrice);

    @Query("SELECT * FROM bitcoin_price ORDER BY timestamp DESC")
    List<BitcoinPrice> getAllPrices();
}